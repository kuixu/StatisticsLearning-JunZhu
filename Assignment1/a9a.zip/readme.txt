# of classes: 2
# of data: 32,561 / 16,281 (testing)
# of features: 123 / 123 (testing)


a9a : training dataset
a9a.t: testing dataset

format: Label [feature id]:[feature] [feature id]:[feature] [feature id]:[feature] [feature id]:[feature] ......

