%% Welcome to the MATLAB tutorial
%% 10-701 Spring 2007
%% Brian Ziebart

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% MATLAB stands for MATrix LABoratory, so you'd better start thinking in
%% matrices
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
function next(start)
   persistent page
   format('compact')
   echo tutorial on
   if (nargin > 0)
       page = start;
   elseif (isempty(page))
       page = 1;
   else
       page = page+1;
   end
   run(sprintf('tutorial%d', page));   
end
