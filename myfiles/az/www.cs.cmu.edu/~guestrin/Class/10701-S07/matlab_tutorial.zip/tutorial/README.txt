10701 MATLAB Tutorial

This tutorial contains 2 script files (tutorial1.m and tutorial2.m) and 
3 examples in the example1, example2, and example3 directories.

The tutorials can be run by setting the current directory to the folder
with the tutorial files (use the "cd" command in the Command Window to do 
this) and then running the next function by inputting "next" into the 
command window.  To run the 2nd tutorial script, type "next" again after
the first script is completed.

The 1st example (in the "example1" directory) shows how to do polynomial
regression.  Change your current directory to "example1" and then type
"regression_example" to run it.

The 2nd example (in the "example2" directory) shows how to load data from
a file and compute probabilities and conditional probabilities of features
of that data.  It can be run by calling the "counting" function in the
example2 directory.  The function shows an example of how a C programmer 
might try to do conditioning and how it can be done much more cleanly and
efficiently using MATLAB matrix functions.  The function also shows examples 
for creating structures and cell arrays.

The 3rd example (in the "example3" directory) provides a little insight into
how MATLAB works "under the hood" and ways that inefficient code can be 
avoided.




Additional Resources:

There are many MATLAB tutorials available on the web.  Here is one that has
been recommended in the class in the past.

 http://www.math.ufl.edu/help/matlab-tutorial/matlab-tutorial.html

