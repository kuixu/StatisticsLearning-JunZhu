%% Welcome to the MATLAB tutorial
%% 10-701 Spring 2007
%% Brian Ziebart

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% MATLAB stands for MATrix LABoratory, so you'd better start thinking in
%% matrices
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function next
   persistent page
   if (isempty(page))
       page = 1
   else
       page = page+1
   return
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Creating a matrix by hand %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A = 3

A = [3]  %% Equivalent scalars

pause;
clc

B = [1 2 3; 4 5 6; 7 8 9]

B = [1,2,3; 4,5,6; 7,8,9]   %% Two ways to make the same matrix

pause;
clc;

C = [1 2 5 9]  %% A 1x4 matrix

end



%    Matrix_Creation();
%end

%
%         D = 1:20
%         D = 1:1:20   %% Equivalent
%
%         E = 1:10:100 %% Every 10th value between 1 and 100
%
%         F = 100:-1:1 %% A countdown from 100 to 1
%
%         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         %% Functions to create special matrices %%
%         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         F = rand        % C ~ Uniform[0,1]
%
%         G = rand(5,5)   % 5x5 matrix
%
%         H = zeros(10,2) % All zeros
%
%         I = ones(10,2)  % All ones
%
%         J = randn       % G ~ Normal(0,1)
%
%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    %% Creating matrices from other matrices %%
%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    K = [H I]
%
%    J = [H; I]
%
%    %%%%%%%%%%%%%%%%%%%%%%%
%    %% Indexing a matrix %%
%    %%%%%%%%%%%%%%%%%%%%%%%
%    B(1)            % Linearly!
%
%    B(2)
%
%    %B(0)            % This is annoying!!!
%
%    B(2,1)          % By matrix position
%
%    B(1,:)          % Get a row of the matrix
%
%    B(:,1)          % Get a column of the matrix
%
%    D([2 3], [3 5]) % Get a 2x2 submatrix
%
%
%
%     function[res] = F(mat)
%         mat(end,end);
%     end
%
% tic()
% A = rand(1000,1000);
% for i=1:100
%     F(A);
% end
% toc()
%
%
%
% end