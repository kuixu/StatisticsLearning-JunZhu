%%% Generate responses from: y = beta * x + epsilon
%%%     where epsilon ~ N(0, sigma)
function[y] = noisy_function(beta, x, sigma)
    y = x * beta + sigma * randn(length(x),1);
end