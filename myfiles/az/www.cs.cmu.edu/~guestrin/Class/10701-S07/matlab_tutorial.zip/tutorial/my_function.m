        function[a,b] = my_function(x,y)  %% Definition
            x = x + 1
            y = y + 3
            a = x * y;
            b = y / x;
        end
