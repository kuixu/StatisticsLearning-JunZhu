function drawchar(table,index)

figure; 
colormap('gray')
imagesc(reshape(table(index,7:70),8,8)'); hold on;
title(sprintf('%c','a'+table(index,2)-1)); 
