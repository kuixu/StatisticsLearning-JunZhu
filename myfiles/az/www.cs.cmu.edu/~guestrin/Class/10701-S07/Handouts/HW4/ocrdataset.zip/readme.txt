Both ocr.mat and ocr-matlab6.mat contain the data set
(ocr-matlab6.mat was saved in format compatible with Matlab 6).

We have already split the whole dataset (variable named "table") into
the training data set (variable "train") and the test data set 
(variable "test").

The subdirectory table_factors/ contains our skeleton implementation
of table factors, along with the header of the methods you need to
implement.  You may find the "Set Path" option in the "File" menu
of Matlab useful.
